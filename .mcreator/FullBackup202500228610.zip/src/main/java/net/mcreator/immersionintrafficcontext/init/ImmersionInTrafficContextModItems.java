/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.immersionintrafficcontext.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.immersionintrafficcontext.item.inventory.RoadEngineeringInventoryCapability;
import net.mcreator.immersionintrafficcontext.item.WasteItem;
import net.mcreator.immersionintrafficcontext.item.TestTubeItem;
import net.mcreator.immersionintrafficcontext.item.RoadEngineeringItem;
import net.mcreator.immersionintrafficcontext.item.RedstoneledtubeItem;
import net.mcreator.immersionintrafficcontext.item.PetroleumItem;
import net.mcreator.immersionintrafficcontext.item.PetroleumInASmallBottleItem;
import net.mcreator.immersionintrafficcontext.item.HammerItem;
import net.mcreator.immersionintrafficcontext.item.AsphaltItem;
import net.mcreator.immersionintrafficcontext.ImmersionInTrafficContextMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ImmersionInTrafficContextModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ImmersionInTrafficContextMod.MODID);
	public static final DeferredItem<Item> PETROLEUM_BUCKET = REGISTRY.register("petroleum_bucket", PetroleumItem::new);
	public static final DeferredItem<Item> WASTE = REGISTRY.register("waste", WasteItem::new);
	public static final DeferredItem<Item> ASPHALT = REGISTRY.register("asphalt", AsphaltItem::new);
	public static final DeferredItem<Item> HAMMER = REGISTRY.register("hammer", HammerItem::new);
	public static final DeferredItem<Item> ASPHALT_MIXING_PLANT = block(ImmersionInTrafficContextModBlocks.ASPHALT_MIXING_PLANT);
	public static final DeferredItem<Item> REDSTONELEDTUBE = REGISTRY.register("redstoneledtube", RedstoneledtubeItem::new);
	public static final DeferredItem<Item> ROUGH_ASPHALT_BLOCK = block(ImmersionInTrafficContextModBlocks.ROUGH_ASPHALT_BLOCK);
	public static final DeferredItem<Item> ASPHALT_ROAD_BLOCK = block(ImmersionInTrafficContextModBlocks.ASPHALT_ROAD_BLOCK);
	public static final DeferredItem<Item> WHITE_ZEBRA_CROSSING = block(ImmersionInTrafficContextModBlocks.WHITE_ZEBRA_CROSSING);
	public static final DeferredItem<Item> TEST_TUBE = REGISTRY.register("test_tube", TestTubeItem::new);
	public static final DeferredItem<Item> PETROLEUM_IN_A_SMALL_BOTTLE = REGISTRY.register("petroleum_in_a_small_bottle", PetroleumInASmallBottleItem::new);
	public static final DeferredItem<Item> JUNCTION_1 = block(ImmersionInTrafficContextModBlocks.JUNCTION_1);
	public static final DeferredItem<Item> JUNCTION_2 = block(ImmersionInTrafficContextModBlocks.JUNCTION_2);
	public static final DeferredItem<Item> JUNCTION_3 = block(ImmersionInTrafficContextModBlocks.JUNCTION_3);
	public static final DeferredItem<Item> ASPHALT_ROAD_BLOCK_ILLUMINATION_LIGHT = block(ImmersionInTrafficContextModBlocks.ASPHALT_ROAD_BLOCK_ILLUMINATION_LIGHT);
	public static final DeferredItem<Item> BITUMINOUS_ORE = block(ImmersionInTrafficContextModBlocks.BITUMINOUS_ORE);
	public static final DeferredItem<Item> ROAD_ENGINEERING = REGISTRY.register("road_engineering", RoadEngineeringItem::new);
	public static final DeferredItem<Item> DUAL_YELLOW_ZEBRA_CROSSING = block(ImmersionInTrafficContextModBlocks.DUAL_YELLOW_ZEBRA_CROSSING);
	public static final DeferredItem<Item> LEFT_TURN_ASPHALT_PAVEMENT_BLOCK = block(ImmersionInTrafficContextModBlocks.LEFT_TURN_ASPHALT_PAVEMENT_BLOCK);
	public static final DeferredItem<Item> YELLOW_ZEBRA_CROSSING = block(ImmersionInTrafficContextModBlocks.YELLOW_ZEBRA_CROSSING);
	public static final DeferredItem<Item> STRAIGHT_AHEAD_ASPHALT_PAVEMENT_BLOCK = block(ImmersionInTrafficContextModBlocks.STRAIGHT_AHEAD_ASPHALT_PAVEMENT_BLOCK);
	public static final DeferredItem<Item> RIGHT_TURN_ASPHALT_PAVEMENT_BLOCK = block(ImmersionInTrafficContextModBlocks.RIGHT_TURN_ASPHALT_PAVEMENT_BLOCK);
	public static final DeferredItem<Item> ASPHALT_PAVEMENT_BLOCKS_FOR_LEFT_AND_RIGHT_TURNS = block(ImmersionInTrafficContextModBlocks.ASPHALT_PAVEMENT_BLOCKS_FOR_LEFT_AND_RIGHT_TURNS);
	public static final DeferredItem<Item> STRAIGHT_AHEAD_AND_LEFT_TURN_ASPHALT_PAVEMENT_BLOCK = block(ImmersionInTrafficContextModBlocks.STRAIGHT_AHEAD_AND_LEFT_TURN_ASPHALT_PAVEMENT_BLOCK);
	public static final DeferredItem<Item> STRAIGHT_AHEAD_AND_RIGHT_TURN_ASPHALT_PAVEMENT_BLOCK = block(ImmersionInTrafficContextModBlocks.STRAIGHT_AHEAD_AND_RIGHT_TURN_ASPHALT_PAVEMENT_BLOCK);
	public static final DeferredItem<Item> U_TURN_ASPHALT_PAVEMENT_BLOCK = block(ImmersionInTrafficContextModBlocks.U_TURN_ASPHALT_PAVEMENT_BLOCK);
	public static final DeferredItem<Item> IRON_DRAWER_CABINET = block(ImmersionInTrafficContextModBlocks.IRON_DRAWER_CABINET);

	// Start of user code block custom items
	// End of user code block custom items
	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.ItemHandler.ITEM, (stack, context) -> new RoadEngineeringInventoryCapability(stack), ROAD_ENGINEERING.get());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}