package net.mcreator.immersionintrafficcontext.procedures;

import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.immersionintrafficcontext.init.ImmersionInTrafficContextModItems;

public class AAAAProcedure {
    public static void execute(LevelAccessor world, double x, double y, double z) {
        BlockPos pos = BlockPos.containing(x, y, z);
        
        // 注释掉这里的重置逻辑，只在处理完成后重置
        // if (getBlockNBTNumber(world, pos, "time") != 0) {
        //     if (!world.isClientSide()) {
        //         BlockPos _bp = BlockPos.containing(x, y, z);
        //         BlockEntity _blockEntity = world.getBlockEntity(_bp);
        //         BlockState _bs = world.getBlockState(_bp);
        //         if (_blockEntity != null)
        //             _blockEntity.getPersistentData().putDouble("time", 0);
        //         if (world instanceof Level _level)
        //             _level.sendBlockUpdated(_bp, _bs, _bs, 3);
        //     }
        // }
        
        // 检查是否满足条件
        if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 8).getCount() <= 48 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() == 0
                && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() == 0 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 7).getCount() == 0
                && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 6).copy()).getItem() == ImmersionInTrafficContextModItems.HAMMER.get()
                && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy()).getItem() == ImmersionInTrafficContextModItems.PETROLEUM_BUCKET.get() && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 6).getCount() == 1
                && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount() == 1 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).getCount() >= 1
                && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).getCount() > 0) {
            
            // 获取当前时间
            long currentTick = getCurrentGameTime(world);
            
            // 获取上次增加时间和当前time值
            double currentNBTTime = getBlockNBTNumber(world, pos, "time");
            long lastTick = getBlockNBTLong(world, pos, "lastTick");
            
            // 如果是第一次或已经过了1秒（20tick）
            if (lastTick == -1 || currentTick - lastTick >= 20) {
                if (currentNBTTime < 61) {
                    // 增加时间值
                    if (!world.isClientSide()) {
                        BlockPos _bp = BlockPos.containing(x, y, z);
                        BlockEntity _blockEntity = world.getBlockEntity(_bp);
                        BlockState _bs = world.getBlockState(_bp);
                        if (_blockEntity != null) {
                            _blockEntity.getPersistentData().putDouble("time", currentNBTTime + 1);
                            _blockEntity.getPersistentData().putLong("lastTick", currentTick); // 使用putLong而不是putDouble
                        }
                        if (world instanceof Level _level)
                            _level.sendBlockUpdated(_bp, _bs, _bs, 3);
                    }
                }
            }
        }
        
        // 保持你原来的代码不变...
        if (getBlockNBTNumber(world, BlockPos.containing(x, y, z), "time") >= 56 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).getCount() >= 6) {
            if (!world.isClientSide()) {
                BlockPos _bp = BlockPos.containing(x, y, z);
                BlockEntity _blockEntity = world.getBlockEntity(_bp);
                BlockState _bs = world.getBlockState(_bp);
                if (_blockEntity != null) {
                    _blockEntity.getPersistentData().putDouble("time", 0);
                    _blockEntity.getPersistentData().remove("lastTick"); // 清理计时标记
                }
                if (world instanceof Level _level)
                    _level.sendBlockUpdated(_bp, _bs, _bs, 3);
            }
            if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                int _slotid = 0;
                ItemStack _stk = _itemHandlerModifiable.getStackInSlot(_slotid).copy();
                _stk.shrink(1);
                _itemHandlerModifiable.setStackInSlot(_slotid, _stk);
            }
            if (world instanceof ILevelExtension _ext && world instanceof ServerLevel _serverLevel && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                int _slotid = 6;
                ItemStack _stk = _itemHandlerModifiable.getStackInSlot(_slotid).copy();
                _stk.hurtAndBreak(1000, _serverLevel, null, _stkprov -> {
                });
                _itemHandlerModifiable.setStackInSlot(_slotid, _stk);
            }
            if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                int _slotid = 2;
                ItemStack _stk = _itemHandlerModifiable.getStackInSlot(_slotid).copy();
                _stk.shrink(6);
                _itemHandlerModifiable.setStackInSlot(_slotid, _stk);
            }
            if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                ItemStack _setstack = new ItemStack(Items.BUCKET).copy();
                _setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).getCount() + 1);
                _itemHandlerModifiable.setStackInSlot(1, _setstack);
            }
            if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                ItemStack _setstack = new ItemStack(ImmersionInTrafficContextModItems.ASPHALT.get()).copy();
                _setstack.setCount(64);
                _itemHandlerModifiable.setStackInSlot(3, _setstack);
            }
            if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                ItemStack _setstack = new ItemStack(ImmersionInTrafficContextModItems.ASPHALT.get()).copy();
                _setstack.setCount(64);
                _itemHandlerModifiable.setStackInSlot(4, _setstack);
            }
            if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                ItemStack _setstack = new ItemStack(ImmersionInTrafficContextModItems.ASPHALT.get()).copy();
                _setstack.setCount(32);
                _itemHandlerModifiable.setStackInSlot(7, _setstack);
            }
            if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                ItemStack _setstack = new ItemStack(ImmersionInTrafficContextModItems.WASTE.get()).copy();
                _setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 8).getCount() + 16);
                _itemHandlerModifiable.setStackInSlot(8, _setstack);
            }
        } else if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).getCount() < 6) {
            if (world instanceof ILevelExtension _ext && _ext.getCapability(Capabilities.ItemHandler.BLOCK, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable)
                _itemHandlerModifiable.setStackInSlot(2, ItemStack.EMPTY);
        }
    }

    private static long getCurrentGameTime(LevelAccessor world) {
        if (world instanceof ServerLevel) {
            return ((ServerLevel) world).getGameTime();
        } else if (world instanceof Level) {
            return ((Level) world).getGameTime();
        }
        return 0;
    }

    private static double getBlockNBTNumber(LevelAccessor world, BlockPos pos, String tag) {
        BlockEntity blockEntity = world.getBlockEntity(pos);
        if (blockEntity != null) {
            if (blockEntity.getPersistentData().contains(tag)) {
                return blockEntity.getPersistentData().getDouble(tag);
            }
        }
        return -1;
    }
    
    private static long getBlockNBTLong(LevelAccessor world, BlockPos pos, String tag) {
        BlockEntity blockEntity = world.getBlockEntity(pos);
        if (blockEntity != null) {
            if (blockEntity.getPersistentData().contains(tag)) {
                return blockEntity.getPersistentData().getLong(tag);
            }
        }
        return -1;
    }

    private static ItemStack itemFromBlockInventory(LevelAccessor world, BlockPos pos, int slot) {
        if (world instanceof ILevelExtension ext) {
            IItemHandler itemHandler = ext.getCapability(Capabilities.ItemHandler.BLOCK, pos, null);
            if (itemHandler != null)
                return itemHandler.getStackInSlot(slot);
        }
        return ItemStack.EMPTY;
    }
}