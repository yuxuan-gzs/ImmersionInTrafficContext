/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.immersionintrafficcontext.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.immersionintrafficcontext.block.YellowZebraCrossingBlock;
import net.mcreator.immersionintrafficcontext.block.WhiteZebraCrossingBlock;
import net.mcreator.immersionintrafficcontext.block.UTurnAsphaltPavementBlockBlock;
import net.mcreator.immersionintrafficcontext.block.StraightAheadAsphaltPavementBlockBlock;
import net.mcreator.immersionintrafficcontext.block.StraightAheadAndRightTurnAsphaltPavementBlockBlock;
import net.mcreator.immersionintrafficcontext.block.StraightAheadAndLeftTurnAsphaltPavementBlockBlock;
import net.mcreator.immersionintrafficcontext.block.RoughAsphaltBlockBlock;
import net.mcreator.immersionintrafficcontext.block.RightTurnAsphaltPavementBlockBlock;
import net.mcreator.immersionintrafficcontext.block.PetroleumBlock;
import net.mcreator.immersionintrafficcontext.block.LeftTurnAsphaltPavementBlockBlock;
import net.mcreator.immersionintrafficcontext.block.Junction3Block;
import net.mcreator.immersionintrafficcontext.block.Junction2Block;
import net.mcreator.immersionintrafficcontext.block.Junction1Block;
import net.mcreator.immersionintrafficcontext.block.IronDrawerCabinetBlock;
import net.mcreator.immersionintrafficcontext.block.DualYellowZebraCrossingBlock;
import net.mcreator.immersionintrafficcontext.block.BituminousOreBlock;
import net.mcreator.immersionintrafficcontext.block.AsphaltRoadBlockIlluminationLightBlock;
import net.mcreator.immersionintrafficcontext.block.AsphaltRoadBlockBlock;
import net.mcreator.immersionintrafficcontext.block.AsphaltPavementBlocksForLeftAndRightTurnsBlock;
import net.mcreator.immersionintrafficcontext.block.AsphaltMixingPlantBlock;
import net.mcreator.immersionintrafficcontext.ImmersionInTrafficContextMod;

public class ImmersionInTrafficContextModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ImmersionInTrafficContextMod.MODID);
	public static final DeferredBlock<Block> PETROLEUM = REGISTRY.register("petroleum", PetroleumBlock::new);
	public static final DeferredBlock<Block> ASPHALT_MIXING_PLANT = REGISTRY.register("asphalt_mixing_plant", AsphaltMixingPlantBlock::new);
	public static final DeferredBlock<Block> ROUGH_ASPHALT_BLOCK = REGISTRY.register("rough_asphalt_block", RoughAsphaltBlockBlock::new);
	public static final DeferredBlock<Block> ASPHALT_ROAD_BLOCK = REGISTRY.register("asphalt_road_block", AsphaltRoadBlockBlock::new);
	public static final DeferredBlock<Block> WHITE_ZEBRA_CROSSING = REGISTRY.register("white_zebra_crossing", WhiteZebraCrossingBlock::new);
	public static final DeferredBlock<Block> JUNCTION_1 = REGISTRY.register("junction_1", Junction1Block::new);
	public static final DeferredBlock<Block> JUNCTION_2 = REGISTRY.register("junction_2", Junction2Block::new);
	public static final DeferredBlock<Block> JUNCTION_3 = REGISTRY.register("junction_3", Junction3Block::new);
	public static final DeferredBlock<Block> ASPHALT_ROAD_BLOCK_ILLUMINATION_LIGHT = REGISTRY.register("asphalt_road_block_illumination_light", AsphaltRoadBlockIlluminationLightBlock::new);
	public static final DeferredBlock<Block> BITUMINOUS_ORE = REGISTRY.register("bituminous_ore", BituminousOreBlock::new);
	public static final DeferredBlock<Block> DUAL_YELLOW_ZEBRA_CROSSING = REGISTRY.register("dual_yellow_zebra_crossing", DualYellowZebraCrossingBlock::new);
	public static final DeferredBlock<Block> LEFT_TURN_ASPHALT_PAVEMENT_BLOCK = REGISTRY.register("left_turn_asphalt_pavement_block", LeftTurnAsphaltPavementBlockBlock::new);
	public static final DeferredBlock<Block> YELLOW_ZEBRA_CROSSING = REGISTRY.register("yellow_zebra_crossing", YellowZebraCrossingBlock::new);
	public static final DeferredBlock<Block> STRAIGHT_AHEAD_ASPHALT_PAVEMENT_BLOCK = REGISTRY.register("straight_ahead_asphalt_pavement_block", StraightAheadAsphaltPavementBlockBlock::new);
	public static final DeferredBlock<Block> RIGHT_TURN_ASPHALT_PAVEMENT_BLOCK = REGISTRY.register("right_turn_asphalt_pavement_block", RightTurnAsphaltPavementBlockBlock::new);
	public static final DeferredBlock<Block> ASPHALT_PAVEMENT_BLOCKS_FOR_LEFT_AND_RIGHT_TURNS = REGISTRY.register("asphalt_pavement_blocks_for_left_and_right_turns", AsphaltPavementBlocksForLeftAndRightTurnsBlock::new);
	public static final DeferredBlock<Block> STRAIGHT_AHEAD_AND_LEFT_TURN_ASPHALT_PAVEMENT_BLOCK = REGISTRY.register("straight_ahead_and_left_turn_asphalt_pavement_block", StraightAheadAndLeftTurnAsphaltPavementBlockBlock::new);
	public static final DeferredBlock<Block> STRAIGHT_AHEAD_AND_RIGHT_TURN_ASPHALT_PAVEMENT_BLOCK = REGISTRY.register("straight_ahead_and_right_turn_asphalt_pavement_block", StraightAheadAndRightTurnAsphaltPavementBlockBlock::new);
	public static final DeferredBlock<Block> U_TURN_ASPHALT_PAVEMENT_BLOCK = REGISTRY.register("u_turn_asphalt_pavement_block", UTurnAsphaltPavementBlockBlock::new);
	public static final DeferredBlock<Block> IRON_DRAWER_CABINET = REGISTRY.register("iron_drawer_cabinet", IronDrawerCabinetBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}